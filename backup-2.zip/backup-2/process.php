
<?php
	$_first=$_POST['name'];
	$_email=$_POST['email'];
	$to="ben.smith83@hotmail.com";
	
	$message="Name:$_first \n\n E-mail:$_email";
	
	if(mail($to,"estateducation.co.uk", $message, "From:$_email")){
	$result='<div class="main_area">
		<div class="thank_content">
			<h2>Thanks for your interest in Estateducation!</h2>
			<p>Once the site launches we will be in touch to let you know about our exciting educational courses, networking events and joint venture opportunities! </p>
		</div>
	</div>'; 
	}
	else{
	$result='<div class="main_area">
		<div class="thank_content">
			<h2>Oops!!!</h2>
			<p>Sorry there was an error sending your message. Please try again later by a valid mail.</p>
		</div>
	</div>';
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>form</title>	
	<meta name="description" content="Motivational Speaker Indonesia">
	<meta name="keywords" content="Motivational Speaker Indonesia,Motivational Speaker Jakarta,Leadership Speaker Indonesia,Keynote Speaker Indonesia">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	
<style type="text/css">
body{background:#ddd}
.main_area {
    min-height: 393px;
    background: #fff;
    text-align: center;
    padding: 35px;
    margin-top:40px;
    min-height:280px;
    background-image: url(img/border_img.png);
    background-repeat: no-repeat;
    background-position: bottom;
	padding-top: 1px;
}	    
.thank_content{
	 margin: 60px auto;
}
.thank_content h2 {
    font-weight: bold;
    font-size:28px;
}
.thank_content p {
    font-size:18px;
    margin-top: 30px;
    line-height: 30px;
} 
  
</style>
  </head>
  <body>
  	<div class="container">
  		<div class="row">
  			<div class="col-md-10 col-md-offset-1 col-xs-12">
  				
				<form class="form-horizontal" role="form" method="post" action="index.php">
					<div class="form-group">
						<div class="col-md-10 col-md-offset-1 col-xs-12 photo">
							<?php echo $result; ?>	
						</div>
					</div> 
				</form> 
			</div>
		</div>
	</div>   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
  </body>
</html>

