<!--add header -->
<?php include_once 'header.php'; ?>

      <!-- Left side column. contains the logo and sidebar -->
<?php include_once 'main_sidebar.php'; ?> <!-- main sidebar area -->
      <!-- Content Wrapper. Contains page content -->
<?php include_once 'welcome.php'; ?>

<?php //include_once 'account.php' ?>

<?php include_once 'footer.php'; ?>