$(function(){
	$(".radio-uniform").uniform();	
});